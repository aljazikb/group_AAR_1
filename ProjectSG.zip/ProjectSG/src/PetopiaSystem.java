
import java.time.LocalDate;
import java.util.*;
//import java.time.format.DateTimeFormatter;
//import java.time.format.DateTimeParseException;

import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;

/**
 *
 * @author aljaz
 */

public class PetopiaSystem {
    //All the arrays we need
    private static Scanner input = new Scanner(System.in);
    private static ArrayList<Client> clients = new ArrayList<Client>();
    private static ArrayList<Booking> bookings = new ArrayList<Booking>();
    //الاضافات الجديده
    static String[] availableTimes = {"09:00 AM", "09:30 AM", "10:00 AM", "10:30 AM","11:00 AM", "11:30 AM", "12:00 PM", "12:30 PM","01:00 PM", "01:30 PM", "02:00 PM",
    "02:30 PM","03:00 PM", "03:30 PM", "04:00 PM", "04:30 PM"};

    
    private static Client currentClient = null;//you
    
    
    public static void main(String[] args) {
         
       mainMenu();
    }
     
    
     
     
    public static void mainMenu() {
    while (true) {  
        
        if (currentClient == null) {
            System.out.println("\nWelcome! What would you like to do?");
            System.out.println("1. Signup");
            System.out.println("2. Login");
            System.out.println("3. Exit");
            System.out.print("Choose: ");
            int choice = input.nextInt();
            input.nextLine(); 

            if (choice == 1) {
                signup();
            } else if (choice == 2) {
                login();
            } else if (choice == 3) {
                System.out.println("Goodbye, See you next time.");
                break;  
            } else {
                System.out.println("Oops! That’s not a valid choice. Please try again.");
            }

        } else { 
            System.out.println("\nWelcome back, " + currentClient.getName() + "! What would you like to do today?");
            System.out.println("1. View your account information");
            System.out.println("2. Book an In-Clinic Appointment");
            System.out.println("3. Book a Home Visit");
            System.out.println("4. Book a Grooming Appointment");
            System.out.println("5. View all your bookings");
            System.out.println("6. Add a new pet to your account");
            System.out.println("7. Logout");

            System.out.print("Please enter your choice: ");
            int C = Integer.parseInt(input.nextLine().trim());
            
            if (C == 1) {
                currentClient.displayAccountInfo();
            } else if (C == 2) {
                bookInClinic();
            } else if (C == 3) {
                bookHomeVisit();
            } else if (C == 4) {
                bookGrooming();
            } else if (C == 5) {
                viewMyBookings();
            } else if (C == 6) {
                addPetToCurrentUser();
            } else if (C == 7) {
                logout();
            } else {
                System.out.println("Oops! That’s not a valid choice. Please try again.");}}}}

     
    
    
    ///no testing on (signup login logout)
    //1
    public static void bookInClinic() {
       
       
       if (!currentClient.hasPets()) {
        System.out.println("You don't have any pets yet. Please add a pet before booking.");
        return;}
       
   
    //Date
       LocalDate bookingDate = null;
       DateTimeFormatter dateFormat = DateTimeFormatter.ofPattern("MM/dd/yyyy");
       
       while (bookingDate == null) {
            System.out.print("Enter the date (MM/DD/YYYY): ");
            String inputDate = input.nextLine().trim();

        try {
            bookingDate = LocalDate.parse(inputDate, dateFormat);
            
            //الحركة الخطيره يشوف الوقت بالماضي نايقبله
            if (bookingDate.isBefore(LocalDate.now())) {
                System.out.println("Date cannot be in the past.");
                bookingDate = null;}
            
        } catch (DateTimeParseException e) {
            System.out.println("Invalid date format. Please use MM/DD/YYYY.");}
        }

    //Time
       int timeIndex = -1;
        
       while (timeIndex == -1) {
            System.out.println("Available times:");
            for (int i = 0; i < availableTimes.length; i++) {
                System.out.printf("%-2d | %s\n", i + 1, availableTimes[i]);}
                System.out.print("Enter the number of your preferred time: ");
        try {
            int choice = Integer.parseInt(input.nextLine().trim());
            
            if (choice >= 1 && choice <= availableTimes.length) {
                timeIndex = choice - 1;
            } else {
                System.out.println("Invalid choice. Pick a number from the list."); }
            
        } catch (NumberFormatException e) {
            System.out.println("Invalid input. Enter a number.");}
        }
        
        String selectedTime = availableTimes[timeIndex];

    // Doctor
        String[] doctors = {"Dr. Ahmed", "Dr. Sarah", "Dr. Khalid", "Dr. Fatima"};
        int doctorIndex = -1;
    
        while (doctorIndex == -1) {
            System.out.println("Available veterinarians:");
            System.out.println("No  | Name");
            System.out.println("--------------------");
            
            for (int i = 0; i < doctors.length; i++) {
                System.out.printf("%-3d | %s\n", i + 1, doctors[i]);}
            
                System.out.print("Enter the number of your choice: ");
        try {
            int choice = Integer.parseInt(input.nextLine().trim());
            if (choice >= 1 && choice <= doctors.length) {
                doctorIndex = choice - 1;
                
            } else {
                System.out.println("Invalid choice. Pick a number from the table.");}
            
        } catch (NumberFormatException e) {
            System.out.println("Invalid input. Enter a number.");}
        
        }
        String selectedDoctor = doctors[doctorIndex];

    // new the booking
    
        bookings.add(new InClinicBooking(currentClient.getName(),bookingDate.format(dateFormat),selectedTime,selectedDoctor));
        
        System.out.println("In-clinic booking confirmed with " + selectedDoctor +" on " + bookingDate.format(dateFormat) + " at " + selectedTime );
    }

    
   //2
    public static void bookHomeVisit() {
       
        if (!currentClient.hasPets()) {
            System.out.println("You don't have any pets yet. Please add a pet before booking.");
            return;}

    // Date
        LocalDate bookingDate = null;
        DateTimeFormatter dateFormat = DateTimeFormatter.ofPattern("MM/dd/yyyy");
        while (bookingDate == null) {
            System.out.print("Enter the date (MM/DD/YYYY): ");
            String inputDate = input.nextLine().trim();
        try {
            bookingDate = LocalDate.parse(inputDate, dateFormat);
        } catch (DateTimeParseException e) {
            System.out.println("Invalid date format. Please use MM/DD/YYYY."); }
    }

    // Time
        int timeIndex = -1;
        while (timeIndex == -1) {
            
            System.out.println("Available times:");
            for (int i = 0; i < availableTimes.length; i++) {
                System.out.printf("%-2d | %s\n", i + 1, availableTimes[i]);
            }
            
            System.out.print("Enter the number of your preferred time: ");
        try {
            int choice = Integer.parseInt(input.nextLine().trim());
            
            if (choice >= 1 && choice <= availableTimes.length) {
                timeIndex = choice - 1;
            } else {
                System.out.println("Invalid choice. Pick a number from the list.");
            }
            
        } catch (NumberFormatException e) {
            System.out.println("Invalid input. Enter a number."); }
    }
        
        String selectedTime = availableTimes[timeIndex];

    // Location
   
        System.out.print("Enter address: ");
        String address = input.nextLine().trim();

   //booking
    bookings.add(new HomeVisitBooking(currentClient.getName(),bookingDate.format(dateFormat),selectedTime,address));
    
    System.out.println("Home visit booking confirmed on " + bookingDate.format(dateFormat) +" at " + selectedTime + " to " + address );
    }

    
    //3
    public static void bookGrooming() {
        if (!currentClient.hasPets()) {
            System.out.println("You don't have any pets yet. Please add a pet before booking.");
            return;}

    // Date
        LocalDate bookingDate = null;
        DateTimeFormatter dateFormat = DateTimeFormatter.ofPattern("MM/dd/yyyy");
        
        while (bookingDate == null) {
            System.out.print("Enter the date (MM/DD/YYYY): ");
            String inputDate = input.nextLine().trim();
        try {
            bookingDate = LocalDate.parse(inputDate, dateFormat);
        } catch (DateTimeParseException e) {
            System.out.println("Invalid date format. Please use MM/DD/YYYY.");
        }
    }

    // time
        int timeIndex = -1;
        while (timeIndex == -1) {
            System.out.println("Available times:");
            
            for (int i = 0; i < availableTimes.length; i++) {
                System.out.printf("%-2d | %s\n", i + 1, availableTimes[i]);}
            
            System.out.print("Enter the number of your preferred time: ");
        try {
            int choice = Integer.parseInt(input.nextLine().trim());
            if (choice >= 1 && choice <= availableTimes.length) {
                timeIndex = choice - 1;
            } else {
                System.out.println("Invalid choice. Pick a number from the list.");
            }
        } catch (NumberFormatException e) {
            System.out.println("Invalid input. Enter a number.");
        }
    }
        
        String selectedTime = availableTimes[timeIndex];

    //      type
        System.out.print("Enter pet type: ");
        String petType = input.nextLine().trim();

    // إنشاء الحجز
        bookings.add(new GroomingBooking(currentClient.getName(),bookingDate.format(dateFormat),selectedTime,petType));
        
    System.out.println("Grooming booking confirmed for your " + petType +" on " + bookingDate.format(dateFormat) + " at " + selectedTime);
    }

    
    
    
    
    
    //4
    public static void viewMyBookings() {
        boolean found = false;
        for (Booking b : bookings) {
            if (b.clientName.equalsIgnoreCase(currentClient.getName())) {
                b.displayDetails();
                found = true;
            }
        }
        if (!found) System.out.println("No bookings found for your account.");
    
    }
     
    //5
    public static void addPetToCurrentUser() {
       // input.nextLine();
         
        System.out.print("Pet name: ");
        String petName = input.nextLine();
        System.out.print("Pet type: ");
        String petType = input.nextLine();
        System.out.print("Pet age: ");
        int age = Integer.parseInt(input.nextLine().trim());
        

        currentClient.addPet(new Pet(petName, petType, age));
        System.out.println("Pet added successfully!");
    }
    
    
    
    public static Client findClientByName(String name) {
         for (Client c : clients) {
            if (c.getName().equalsIgnoreCase(name)) {
                return c;
            }
        }
        return null;
    }
    
   
    
    public static void signup() {
        System.out.print("Enter your name: ");
        String name = input.nextLine();

        // Prevent duplicates
        if (findClientByName(name) != null) {
            System.out.println(" That name is already taken. Try logging in.");
            return; }

        System.out.print("Enter your email: ");
        String email = input.nextLine();
        System.out.print("Enter your phone: ");
        String phone = input.nextLine();
        System.out.print("Create a password: ");
        String password = input.nextLine();

        Client newClient = new Client(name, email, phone, password);
        clients.add(newClient);
        System.out.println(" Account created successfully! You can now log in.");}
    
    
    public static void login() {
        
        System.out.print("Enter your name: ");
        String name = input.nextLine().trim();
        System.out.print("Enter your password: ");
        String pass = input.nextLine().trim();

        Client client = findClientByName(name);
        if (client != null && client.checkPassword(pass)) {
            currentClient = client;
            System.out.println(" Login successful! Welcome, " + currentClient.getName());
        } else {
            System.out.println("Invalid name or password.");}}

    
    public static void logout() {
        System.out.println(" Logged out successfully. Bye " + currentClient.getName() + "!");
        currentClient = null;}
    
    

}
    

