/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit4TestClass.java to edit this template
 */

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author aljaz
 */
public class PetopiaSystemTest {
    
    public PetopiaSystemTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of main method, of class PetopiaSystem.
     */
    @Test
    public void testMain() {
        System.out.println("main");
        String[] args = null;
        PetopiaSystem.main(args);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of mainMenu method, of class PetopiaSystem.
     */
    @Test
    public void testMainMenu() {
        System.out.println("mainMenu");
        PetopiaSystem.mainMenu();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of bookInClinic method, of class PetopiaSystem.
     */
    @Test
    public void testBookInClinic() {
        System.out.println("bookInClinic");
        PetopiaSystem.bookInClinic();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of bookHomeVisit method, of class PetopiaSystem.
     */
    @Test
    public void testBookHomeVisit() {
        System.out.println("bookHomeVisit");
        PetopiaSystem.bookHomeVisit();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of bookGrooming method, of class PetopiaSystem.
     */
    @Test
    public void testBookGrooming() {
        System.out.println("bookGrooming");
        PetopiaSystem.bookGrooming();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of viewMyBookings method, of class PetopiaSystem.
     */
    @Test
    public void testViewMyBookings() {
        System.out.println("viewMyBookings");
        PetopiaSystem.viewMyBookings();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of addPetToCurrentUser method, of class PetopiaSystem.
     */
    @Test
    public void testAddPetToCurrentUser() {
        System.out.println("addPetToCurrentUser");
        PetopiaSystem.addPetToCurrentUser();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of findClientByName method, of class PetopiaSystem.
     */
    @Test
    public void testFindClientByName() {
        System.out.println("findClientByName");
        String name = "";
        Client expResult = null;
        Client result = PetopiaSystem.findClientByName(name);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of signup method, of class PetopiaSystem.
     */
    @Test
    public void testSignup() {
        System.out.println("signup");
        PetopiaSystem.signup();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of login method, of class PetopiaSystem.
     */
    @Test
    public void testLogin() {
        System.out.println("login");
        PetopiaSystem.login();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of logout method, of class PetopiaSystem.
     */
    @Test
    public void testLogout() {
        System.out.println("logout");
        PetopiaSystem.logout();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }
    
}
