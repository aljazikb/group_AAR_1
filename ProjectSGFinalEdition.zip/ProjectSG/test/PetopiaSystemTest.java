/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit4TestClass.java to edit this template
 */

import java.util.ArrayList;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;

import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author aljaz
 */
public class PetopiaSystemTest {
    
 Client objTest;
 
 @Before
 
 public void setup(){
     
     PetopiaSystem.bookings.clear();
     
     //public Client(String name, String email, String phone, String password)
    objTest=new Client("Aljazi","aljazikb@gmail.com","0540505484","209876");
    PetopiaSystem.clients.add(objTest);
    PetopiaSystem.currentClient=objTest;
    
    //public Pet(String name, String type, int age)
    objTest.addPet(new Pet("Alex","Afghan Hound",2)); 
    
 }
 
 @Test
 
 public void testAddPetToCurrentUser(){
     objTest.addPet(new Pet("bob","Husky",5));
     objTest.addPet(new Pet("buddy","Husky",1));
     
     String[] exp = {"Alex","bob", "buddy"};
     
     ArrayList<Pet> pets = PetopiaSystem.currentClient.getPets();
     
     String[] actual = new String[pets.size()];
     for (int i = 0; i < pets.size(); i++) {
        actual[i] = pets.get(i).getName();
    }
     
     assertArrayEquals(exp, actual);
     
 }
 
 @Test
 
 public void testbookInClinic(){
     
     //PetopiaSystem.bookings.clear();// 
      
     // public InClinicBooking(String clientName, String date, String time, String veterinarianName)
     InClinicBooking b1 = new InClinicBooking (objTest.getName(), "11/20/2025", "10:00 AM","Dr.Ahmed");
     InClinicBooking b2 = new InClinicBooking(objTest.getName(), "11/21/2025", "09:30 AM","Dr.Omar");
     
     PetopiaSystem.bookings.add(b1);
     PetopiaSystem.bookings.add(b2);
     
     String[] exp = {"11/20/2025", "11/21/2025"};
     
     String[] actual = new String[PetopiaSystem.bookings.size()];
     for (int i = 0; i < PetopiaSystem.bookings.size(); i++) {
        actual[i] = PetopiaSystem.bookings.get(i).date;
      }
     
     assertArrayEquals(exp, actual);
    }

 @Test
 
 public void testbookInClinicIsSave(){
     //PetopiaSystem.bookings.clear();
     
     InClinicBooking b = new InClinicBooking(PetopiaSystem.currentClient.getName(),"11/20/2025","10:00 AM","Dr. Ahmed");
     
     PetopiaSystem.bookings.add(b);

     assertEquals(1, PetopiaSystem.bookings.size());
 }
 
 @Test
 
 public void testBookHomeVisit(){
     //PetopiaSystem.bookings.clear();
     
     HomeVisitBooking b = new HomeVisitBooking(objTest.getName(),"11/26/2025","2:00 PM","123 Main St");
     PetopiaSystem.bookings.add(b);
     
     String[] expected = {"123 Main St"};
     
     HomeVisitBooking book = (HomeVisitBooking) PetopiaSystem.bookings.get(0);

     String[] actual = {book.getAddress()};

    assertArrayEquals(expected, actual);
 }
 
 
 
 
 @Test
 
 public void testBookGrooming(){
     //public GroomingBooking(String clientName, String date, String time, String petType)
     GroomingBooking b = new GroomingBooking(objTest.getName(), "11/27/2025", "1:00 PM", "Dog");
     PetopiaSystem.bookings.add(b); 
     
     String[] expPetTypes = {"Dog"};
     
    
     GroomingBooking book= (GroomingBooking) PetopiaSystem.bookings.get(0);
     String[] actual = {book.getPetType()};
     
     assertArrayEquals(expPetTypes, actual);

 }
 
 
 @Test
 
 public void testViewMyBookingsNumOfBooking(){
      PetopiaSystem.bookings.add(new InClinicBooking(objTest.getName(), "11/25/2025", "10:00 AM", "Dr. Ahmed"));
      PetopiaSystem.bookings.add(new GroomingBooking(objTest.getName(), "11/27/2025", "1:00 PM", "Dog"));
      
      int count = 0;
      for (Booking b : PetopiaSystem.bookings) {
         if (b.clientName.equalsIgnoreCase(objTest.getName())) {
            count++;}
        }
      
      assertEquals(2, count);
 
}


   
 
 
 
 
}
